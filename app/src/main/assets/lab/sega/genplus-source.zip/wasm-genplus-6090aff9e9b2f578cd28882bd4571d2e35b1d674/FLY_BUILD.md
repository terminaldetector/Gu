FlyConsole API6: Genesis Plus GX 49c584764893b0505ac7f768a754f97330fa4392; Emscripten 3.1.57.
Original wasm-genplus wrapper retained with FlyConsole controller, video,
audio, region and snapshot adapters. Cartridge limit 32 MiB.
Build with: emcmake cmake -S . -B build-fly; cmake --build build-fly -j4.
