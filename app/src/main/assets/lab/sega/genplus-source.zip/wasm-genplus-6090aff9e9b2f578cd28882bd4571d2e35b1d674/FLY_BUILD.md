# Fly Console Genesis core source
Upstream: h1romas4/wasm-genplus, commit 6090aff9e9b2f578cd28882bd4571d2e35b1d674.
Modifications: wasm/wasm.c exports logical 64 KiB work RAM, state save/load, viewport, reset and PAL/NTSC frame rate. State buffer allocation added. wasm/config.c uses automatic region/video/master-clock detection. CMake minimum is 3.5. v1.0.1 fixes CUSTOM_BLITTER in core/vdp_render.h: native-resolution RGBA rows, byte-based pitch, no erroneous doubled-row writes outside the framebuffer.
Build with Emscripten 3.1.57, CMake >=3.5, make:
```
mkdir build
cd build
emcmake cmake ..
emmake make -j4
cd ..
```
The generated files are src/main/js/genplus.js and genplus.wasm. For a classic browser script append:
```
if(typeof window!=="undefined")window.GenPlusFactory=Module;
```
Fly's frontend adapter is separately provided as app/src/main/assets/lab/sega-core.js in the application repository. All source components of this modified core are included here. Original notices in every source file remain intact. Noncommercial redistribution; see LICENSE.txt and component notices.

API4: 64-float input buffer; independent pad[0]/pad[4] controllers; lab_core_api() = 4. Rebuild via tools/build_sega.py in Gu.
